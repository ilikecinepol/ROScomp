"""Бортовой запуск отдельного испытания из панели; без команд при импорте."""
import argparse
import asyncio
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys
import queue
import threading
from types import SimpleNamespace

TEAM=Path('/home/ubuntu/ai-robot/team_wolf_setup')
SDK=Path('/home/ubuntu/ai-robot')


def emit(value):
    print(json.dumps(value,ensure_ascii=False),flush=True)


class StatusOutput:
    """Медленный SSH не блокирует бортовой цикл движения: хранится последний статус."""
    def __init__(self):
        self.queue=queue.Queue(maxsize=1)
        self.thread=threading.Thread(target=self.work,daemon=True)
        self.thread.start()

    def put(self,value):
        try:self.queue.put_nowait(value)
        except queue.Full:
            try:self.queue.get_nowait()
            except queue.Empty:pass
            try:self.queue.put_nowait(value)
            except queue.Full:pass

    def work(self):
        while True:
            value=self.queue.get()
            if value is None:return
            try:emit(value)
            except (BrokenPipeError,OSError):return

    def close(self):
        self.put(None)
        self.thread.join(timeout=.2)


def service(action):
    subprocess.run(['sudo','-n','systemctl',action,'fleet-dog'],check=True,timeout=20,
                   stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)


def active():
    return subprocess.run(['systemctl','is-active','--quiet','fleet-dog'],timeout=5).returncode==0


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--kind',choices=['slalom','aframe','teeter','platforms'])
    p.add_argument('--stage-next',choices=['aframe'])
    p.add_argument('--check',action='store_true')
    args=p.parse_args()
    if not args.check and not args.kind:
        p.error('Нужен вид препятствия')
    from wolf_go2.profile import RobotProfile
    profile_path=TEAM/'autonomy-profile.json'
    if not profile_path.is_file():
        emit({'type':'error','reason':'Нет бортового профиля autonomy-profile.json. Нужны проверка координат, лидара и локализации; движение не запущено.'})
        return 2
    profile=RobotProfile.load(profile_path)
    errors=profile.readiness(profile.robot_id)
    if args.kind and args.kind not in profile.policy.validated_skills:
        errors.append('Не подтверждён навык '+args.kind)
    if args.stage_next and args.stage_next not in profile.policy.validated_skills:
        errors.append('Не подтверждён следующий объект '+args.stage_next)
    if errors:
        emit({'type':'error','reason':'; '.join(errors)})
        return 2
    if args.check:
        emit({'type':'checked','reason':'Профиль прочитан. Свежие датчики будут проверены при запуске.','robot_id':profile.robot_id})
        return 0
    import fcntl
    # Тот же замок, что у ручного управления. Другие сеансы не завершаем.
    with (TEAM/'teleop.lock').open('a') as lease:
        try:
            fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            emit({'type':'error','reason':'Завершите ручной сеанс: робот уже занят нашим клиентом.'})
            return 2
        restore=False
        try:
            if active():
                restore=True
                service('stop')
            from wolf_go2.runtime import run_session
            stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
            output=TEAM/'autonomy_logs'/stamp
            statuses=StatusOutput()
            settings=SimpleNamespace(mode='live',profile=str(profile_path),robot_id=profile.robot_id,
                sdk_dir=str(SDK),output=str(output),start_file=str(TEAM/('start-'+stamp)),
                duration=240.,trial_kind=args.kind,stage_next=args.stage_next,
                button_start=True,status_sink=statuses.put)
            emit({'type':'connecting','reason':'Соединяемся и проверяем свежие датчики','output':str(output)})
            try:report=asyncio.run(run_session(settings))
            finally:statuses.close()
            emit({'type':'result',**report})
            return 2 if report.get('fault') or report.get('mission_phase')!='FINISHED' or report.get('stop_acknowledged') is not True else 0
        finally:
            if restore:
                try:
                    service('start')
                    emit({'type':'restored','ok':active()})
                except Exception as exc:
                    emit({'type':'error','reason':'Не удалось восстановить fleet-dog: '+str(exc)})


if __name__=='__main__':
    try:
        raise SystemExit(main())
    except Exception as exc:
        emit({'type':'error','reason':type(exc).__name__+': '+str(exc)})
        raise SystemExit(2)
